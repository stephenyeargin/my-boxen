# Linkinus Puppet Module for Boxen

[![Build Status](https://travis-ci.org/boxen/puppet-linkinus.png?branch=master)](https://travis-ci.org/boxen/puppet-linkinus)

Installs [Linkinus](http://conceited.net/products/linkinus), an IRC client.

## Usage

```puppet
include linkinus
```

## Required Puppet Modules

* boxen

